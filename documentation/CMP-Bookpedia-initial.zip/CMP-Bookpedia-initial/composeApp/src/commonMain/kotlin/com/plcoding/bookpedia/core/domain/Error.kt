package com.plcoding.bookpedia.core.domain

interface Error